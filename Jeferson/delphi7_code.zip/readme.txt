Mastering Delphi 7 source code - README.TXT

The source code of the book Mastering Delphi 7 is available on the author and
publisher web sites. For information about the book see http://www.marcocantu.com
and http://www.sybex.com.

You can open and compile specific project. For compiling an entire chapter in
batch from the command line you can use the want.xml files provided in each
chapter's folder. A main want.xml file starts a complete compilation. You need
to downalod the want build tool from http://www.suigeneris.org/want.

All the source code is Copyright Marco Cant� 2003

SYBEX and the author hereby grant to you a license to use the Software, subject
to the terms that follow. Your purchase, acceptance, or use of the Software will
constitute your acceptance of such terms.
The source code is provided as-is with no garantuees whatsoever. Its only scope
is to help you learn Delphi.
The source code is protected by copyright to Marco Cant�. You are hereby granted
a single-user license to use compile and test the programs and to include any
code portion in programs you are developing. You are not allowed to publish and
reproduce the code as it is. Feeel free to direct others to the downalod page.
The author is in no way responsible for providing any support for the source 
code, nor is it liable or responsible for any support provided, or not provided. 
Feel free to psot corrections and comments directly to the author via his 
newsgroups or email.

The author makes no warranty or representation, either expressed or implied,
with respect to the source code or its contents, quality, performance,
merchantability, or fitness for a particular purpose. In no event will the
author, its publisher, its distributors, or dealers be liable to you or any
other party for direct, indirect, special, incidental, consequential, or other
damages arising out of the use of or inability to use the code or its contents
even if advised of the possibility of such damage.
